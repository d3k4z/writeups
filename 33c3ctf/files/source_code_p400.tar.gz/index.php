<?php 
    include("functions.php");
    include("header.php");
?>


<?php

if (isset($_GET["page"])) {
    include $_GET["page"] . ".php";
} else if (logged_in()) {
    $lists = get_lists();
?>
<div class="container">
    <div class="row">
        <legend class="h2"><strong>Your lists</strong></legend>
        <div class="col-md-6">
        <?php
            if (count($lists) === 0) {
                echo "You don't have any lists br0. Don't let your dreams be dreams! <a href=\"?page=list&action=new\">create some</a> ...";
            }
        ?>
            <ul class="list-group">
<?php
    foreach($lists as $list) {
        $num = count(get_list_items($list["id"]));
        echo "<a href=\"?page=list&action=show&list={$list["id"]}\"><li class=\"list-group-item\"><p><h4>{$list["name"]}</h4> {$num} items</p></li></a>";
    }
?>
            </ul>
        </div>
    </div>
</div>
<?php
} else {
?>
    <div class="jumbotron text-center">
        <h1>Listo_0r</h1>
        <blockquote class="quote-card">
        <?php echo random_shit_quote(); ?>
        </blockquote>
    </div>
    <div class="container">
        <div class="row">
            <h3>Bored in life? create some lists</h3>
            <p>Cause lists are cool. <a href="?page=register">Register now</a> so we can spam you with useless promotional shit.</p>
    </div>
<?php
}
?>

</body>
</html>

